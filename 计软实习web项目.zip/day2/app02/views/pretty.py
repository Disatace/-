from django.shortcuts import render,redirect
from app02.models  import Department,UserInfo,PrettyNum
from app02.utils.pagination import Pagination
from app02.utils.form import PrettyModelForm

def pretty_list(request):
    # for i in range(100):
    #     PrettyNum.objects.create(mobile="12345678911",price=10,level=1,status=1)
    data_dict = {}
    search_data = request.GET.get('q',"")
    if search_data:
        data_dict["mobile__contains"] = search_data #contains 搜索 q的值
    # res = PrettyNum.objects.filter(**data_dict)
    # print(res)
    #分页

    queryset = PrettyNum.objects.filter(**data_dict).order_by("-level")
    page_object = Pagination(request, queryset)

    page_queryset = page_object.page_queryset
    page_string = page_object.html()
    #数据总条数
    # total_count = PrettyNum.objects.filter(**data_dict).order_by("-level").count()
    #页码
    context = {
        'search_data':search_data,

        'queryset':page_queryset,
        'page_string':page_string
    }
    return render(request,'pretty_list.html',context)




def pretty_add(request):
    if request.method == "GET":
        form = PrettyModelForm
        return render(request, 'pretty_add.html',{'form':form})
    form = PrettyModelForm(data=request.POST)
    if form.is_valid():
        form.save()
        return redirect('/pretty/list/')
    return render(request, 'pretty_add.html', {'form': form})

def pretty_edit(request,nid):
    if request.method == "GET":
        row_object = PrettyNum.objects.filter(id=nid).first()

        form = PrettyModelForm(instance=row_object)
        return  render(request,'pretty_edit.html',{'form':form })

    row_object = PrettyNum.objects.filter(id=nid).first()
    form = PrettyModelForm(data=request.POST,instance=row_object)
    if form.is_valid():
        form.save()
        return redirect('/pretty/list/')

    return render(request,'pretty_edit.html',{"form":form})

def pretty_delete(request,nid):
    PrettyNum.objects.filter(id=nid).delete()
    return redirect('/pretty/list/')