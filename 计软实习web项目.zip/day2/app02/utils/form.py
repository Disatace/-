from django.core.exceptions import ValidationError
from app02.models  import Department,UserInfo,PrettyNum
from app02.utils.bootstrao import BootStrapModelForm
from django import forms
from django.core.validators import RegexValidator




class UserModelForm(BootStrapModelForm):
    name = forms.CharField(
        min_length=3,
        label="用户名",
        widget=forms.TextInput(attrs={"class": "form-control"})
    )
    class Meta:
        model = UserInfo
        fields = ["name","password","age",'account','create_time','depart','gender']
        # widgets = {
        #     "name" : forms.TextInput(attrs={"class":"form-control"}),
        #     "password" : forms.TextInput(attrs={"class":"form-control"}),
        #     "age" : forms.TextInput(attrs={"class":"form-control"}),
        #     "account" : forms.TextInput(attrs={"class":"form-control"}),
        #     "create_time" : forms.TextInput(attrs={"class":"form-control"}),
        #     "" : forms.TextInput(attrs={"class":"form-control"})
        # }

    # def __init__(self,*args,**kwargs):
    #     super().__init__(*args,**kwargs)
    #
    #     for name,field in self.fields.items():
    #         # print(name,field)
    #         if field.widget.attrs:
    #             field.widget.attrs["class"] = "form-control"
    #             field.widget.attrs["placeholder"] = field.label
    #         else:
    #             field.widget.attrs = {
    #                 "class":"form-control",
    #                 "placeholder": field.label
    #                                   }


class PrettyModelForm(BootStrapModelForm):
    mobile = forms.CharField(
        label="手机号",
        validators=[RegexValidator(r'^1[3-9]\d{9}$','手机号格式错误'),],
    )
    class Meta:
        model = PrettyNum
        fields = "__all__"

    # def __init__(self,*args,**kwargs):
    #     super().__init__(*args,**kwargs)
    #     for name,field in self.fields.items():
    #         print(name,field)
    #         field.widget.attrs = {"class":"form-control"}
    #方法2：钩子函数
    def clean_mobile(self):
        txt_mobile = self.cleaned_data["mobile"]
        exists = PrettyNum.objects.exclude(id=self.instance.pk).filter(mobile=txt_mobile).exists()
        if exists:
            raise ValidationError("手机号已存在")

        return  txt_mobile